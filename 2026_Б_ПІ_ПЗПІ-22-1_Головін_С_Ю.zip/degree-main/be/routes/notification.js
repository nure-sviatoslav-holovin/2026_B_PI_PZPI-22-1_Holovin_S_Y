'use strict';

const { Notification } = require('../models/Notification');
const express = require('express');
const { createAuthMiddleware } = require('../services/createAuthMiddleware');
const { roles } = require('../services/roles');

const router = express.Router();

const getAll = async (req, res) => {
  try {
    const notifications = await Notification.findAll();
    res.send(notifications);
  } catch (err) {
    res.status(400).send(err.message);
  }
};

const getOne = async (req, res) => {
  const { id } = req.params;

  try {
    const notification = await Notification.findByPk(id);
    if (!notification) {
      return res.status(404).send('Notification not found');
    }
    res.send(notification);
  } catch (err) {
    res.status(400).send(err.message);
  }
};

const add = async (req, res) => {
  const notificationData = { ...req.body };

  try {
    const notification = await Notification.create(notificationData);
    res.status(201).send(notification);
  } catch (err) {
    res.status(400).send(err.message);
  }
};

const update = async (req, res) => {
  const { id } = req.params;
  const notificationData = { ...req.body };

  try {
    await Notification.update(notificationData, { where: { id } });
    const notification = await Notification.findByPk(id);
    if (!notification) {
      return res.status(404).send('Notification not found');
    }
    res.send(notification);
  } catch (err) {
    res.status(400).send(err.message);
  }
};

const remove = async (req, res) => {
  const { id } = req.params;

  try {
    const deleted = await Notification.destroy({ where: { id } });
    if (!deleted) {
      return res.status(404).send('Notification not found');
    }
    res.status(204).send({});
  } catch (err) {
    res.status(400).send(err.message);
  }
};

router.get(
  '/',
  ...createAuthMiddleware([roles.ADMIN, roles.TEACHER]),
  getAll,
);
router.get(
  '/:id',
  ...createAuthMiddleware([roles.ADMIN, roles.TEACHER]),
  getOne,
);
router.post('/', ...createAuthMiddleware([roles.ADMIN]), add);
router.patch('/:id', ...createAuthMiddleware([roles.ADMIN]), update);
router.delete('/:id', ...createAuthMiddleware([roles.ADMIN]), remove);

module.exports = { router };
